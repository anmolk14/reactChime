---
name: Documentation Request
about: Need help using the Component Library? Spot an error? Let us know how our documentation
  can be improved.
title: ''
labels: Documentation
assignees: ''

---

### What are you trying to do?

*For example: I'm trying to run the demo app.*

### How can the documentation be improved to help your use case?

*For example: Include a section on how to configure a component.*

### What documentation have you looked at so far?

*For example: README.md, Amazon Chime Component Library Guide, etc.
